# StreamX Media3 Pro v16.0 – ULTRA MAX EDITION — Complete Deep Upgrade Changelog

## Version Metadata
- **Application Name**: `StreamX Media3 Pro v16.0 – ULTRA MAX EDITION`
- **Package ID**: `com.harindra.iptvpro`
- **Version Name**: `16.0`
- **Version Code**: `160`
- **SDK Targets**: `minSdk = 23` (Android 6.0+ Smart TVs), `targetSdk = 34`, `compileSdk = 36`
- **Media3 Engine**: `androidx.media3:1.11.1` (ExoPlayer Core, HLS, DASH, RTSP, UI, Common, OkHttp DataSource)

## 1. Complete Premium 4D Hyper-Glass UI/UX & Icon System Upgrade
- **5-State 4D Crystal Glass Selectors (`bg_btn_3d_*.xml`, `bg_channel_row_4d.xml`, `bg_dialog_item_4d.xml`, `bg_glass_input_4d.xml`)**:
  - Added dedicated `state_pressed` (tactile sunken 4D capsule), `state_focused` (high-visibility 10-foot TV neon border + top crystal reflection), `state_selected` (active tab/row glow), `state_enabled="false"` (clean muted disabled state), and resting 4D beveled glass states.
- **Refined 4D Micro-Interactions (`PlayerActivity.attach4dFocusMicroInteraction`)**:
  - Smooth `110ms` hardware-accelerated scale lift (`1.035x` on buttons, `1.02x` on channel/modal cards) on D-Pad focus transitions with zero object allocation during scrolling.
- **Upgraded 3D/4D Vector Icon System (`ic_3d_*.xml`, `tv_banner.xml`)**:
  - Added multi-layer 4D drop shadows, inner specular highlights, and unified `20dp` viewport proportions across `ic_3d_recall.xml`, `ic_3d_category.xml`, `ic_3d_pip.xml`, `ic_3d_ram_gauge.xml`, and `tv_banner.xml`.

## 2. Android TV D-Pad Navigation & Remote Control Deep Optimization
- **Explicit Focus Order (`activity_player.xml`)**:
  - Added `android:nextFocusLeft`, `android:nextFocusRight`, `android:nextFocusUp`, and `android:nextFocusDown` across the top navigation bar, left channel drawer tabs (`All Live TV`, `★ Favorites`, `⟲ Recent`), search input, category spinner, channel list `RecyclerView`, and bottom OSD controls (`⟲`, `☆`, `CH-`, `CH+`).
  - Added `android:contentDescription` labels across interactive controls for screen-reader and accessibility compatibility.
- **Full Android TV Remote Key Support (`PlayerActivity.onKeyDown`)**:
  - Added support for `KEYCODE_PAGE_UP` / `KEYCODE_PAGE_DOWN` (channel zap), `KEYCODE_INFO` / `KEYCODE_GUIDE` / `KEYCODE_PROG_GREEN` (opens 4D Electronic Program Guide Hub), `KEYCODE_PROG_RED` (instant Favorite toggle), `KEYCODE_MEDIA_AUDIO_TRACK` / `KEYCODE_CAPTIONS` / `KEYCODE_PROG_YELLOW` (Audio/Quality/Subtitles modal), `KEYCODE_SETTINGS` / `KEYCODE_PROG_BLUE` (4D Studio & Diagnostics modal), and `KEYCODE_MEDIA_PLAY_PAUSE` (play/pause + live-edge sync).
  - Prevented numeric keys `0-9` from hijacking input when typing inside the drawer `channelSearch` field.

## 3. Extreme Channel Zapping & Media3 Player Engine Upgrade
- **Hardware Async Queueing & Fast Keyframe Lock (`PlayerActivity.initializeMedia3ProEngine`)**:
  - Enabled `DefaultRenderersFactory.forceEnableMediaCodecAsynchronousQueueing()` and `setEnableDecoderFallback(true)` alongside `EXTENSION_RENDERER_MODE_OFF` for 512MB RAM Android TVs.
  - Configured `ExoPlayer.Builder.setSeekParameters(SeekParameters.CLOSEST_SYNC)` for faster keyframe lock during channel zapping and live-edge resynchronization.
- **Instant Live Window Drift Recovery**:
  - Handled `PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW` by immediately seeking to live default position and re-preparing without consuming a retry slot or displaying an error toast.
- **High-Contrast TV Subtitle Styling**:
  - Configured `playerView.subtitleView` with `18sp` bold white text, drop-shadow edge, and translucent dark obsidian background (`#B8040B18`) for 10-foot viewing distance readability.
- **Zero-Regex HLS Preload Target Parser (`StreamPreFetcher.kt`)**:
  - Replaced Regex allocations in `parseHlsPlaylistTargets` with character-level scanners (`extractLongAttrFast`, `extractResolutionHeightFast`, `extractQuotedUriAttrFast`) and added automatic VOD vs. Live `MediaItem` configuration in `buildLiveMediaItem`.

## 4. Xtream Codes, M3U/M3U8 & XMLTV EPG Engine Upgrades
- **Xtream Codes Repository (`XtreamRepository.kt`)**:
  - Added `fetchMutex` deduplication, `cancelActiveFetch()` in-flight call cancellation, and automatic retry with backoff on transient HTTP 5xx / network errors.
  - Added automatic Dual-Stream Failover (`backupUrl`): pairs primary `.m3u8` live stream URLs with `.ts` direct MPEG-TS fallback URLs so channels auto-failover if HLS transcoding stalls.
  - Added `fetchVodStreams` (`get_vod_categories` + `get_vod_streams`) integrated into the Accounts menu (`Load Xtream VOD Movies Catalog`).
- **M3U / M3U8 Parser (`M3uParser.kt`)**:
  - Added support for unquoted `#EXTINF` attributes (`tvg-id=...`, `tvg-chno=...`), custom channel numbers (`tvg-chno` / `ch-number`), `#EXTVLCOPT:http-origin` / `http-cookie`, and smart category inference (`Movies`, `Series`, `Sports`, `News`, `Music`, `Kids`) when `group-title` is omitted.
- **XMLTV EPG & 4D TV Guide Hub (`XmltvParser.kt`, `EpgCacheStore.kt`, `PlayerActivity.kt`)**:
  - Extracted programme `<desc>`, start/stop time windows (`HH:mm - HH:mm`), live progress percentage (`0..100%`), `<channel><display-name>` aliases, and normalized alphanumeric keys (`normalizeEpgKey`) for high-accuracy channel-to-EPG matching.
  - Added interactive `showEpgGuideHubDialog()` to inspect current programme details/descriptions and browse 40+ channels' live Now/Next schedules.

## 5. RAM, Cache, Security & CI/CD Workflow Optimization
- **Coordinated 512MB RAM Trimming (`StreamXApp.kt`, `ChannelCacheStore.kt`, `EpgCacheStore.kt`, `XmltvParser.kt`, `NetworkClient.kt`)**:
  - Added `ChannelCacheStore.trimMemoryCache()`, `EpgCacheStore.trimMemoryCache()`, `XmltvParser.trimProgrammeDetailsCache()`, and `NetworkClient.evictIdleConnections()` triggered on `onTrimMemory` / `onLowMemory`.
- **Security & Input Sanitization (`ProfileStore.kt`, `NetworkClient.kt`)**:
  - Added `ProfileStore.sanitizeExternalInput` to strip zero-width/BOM characters and whitespace from user-entered URLs and credentials.
  - Extended `NetworkClient.redactSensitiveUrl` to mask credentials in `/live/`, `/movie/`, and `/series/` paths as well as query tokens.
- **GitHub Actions Workflow (`.github/workflows/build_apk.yml` & `StreamX_GitHub_Actions_build_apk.yml`)**:
  - Verified single-APK release pipeline building `StreamX-Media3-Pro-v16.0-Ultra-Max-Edition-512MB.apk` using JDK 17, preinstalled Android SDK 36 `sdkmanager`, and Gradle 8.13.
